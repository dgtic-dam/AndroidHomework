package mx.unam.tic.docencia.webserviceexample.listener

interface OnArticleClickListener {

    fun onArticleClick(title: String)
}